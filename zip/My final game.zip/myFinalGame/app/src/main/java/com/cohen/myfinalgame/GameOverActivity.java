package com.cohen.myfinalgame;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;


public class GameOverActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        // Find the final score TextView
        TextView finalScoreText = findViewById(R.id.finalScoreText);

        // Get the score from the Intent
        int score = getIntent().getIntExtra("score", 0);

        // Display the score
        finalScoreText.setText("Final Score: " + score);

        // Play Again Button
        Button playAgainButton = findViewById(R.id.playAgainButton);
        playAgainButton.setOnClickListener(v -> {
            // Logic to restart the game
            Intent intent = new Intent(GameOverActivity.this, GameActivity.class);
            startActivity(intent);
            finish();
        });

        // Exit Button
        Button exitButton = findViewById(R.id.exitButton);
        exitButton.setOnClickListener(v -> {
            // Exit the game
            finishAffinity();
        });
    }
}
